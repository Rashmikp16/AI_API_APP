# AI REST API (FastAPI)

This project provides three REST APIs for common AI tasks:
- `POST /summarize`
- `POST /translate`
- `POST /generate-email`

## Features
- Request validation using Pydantic schemas
- Centralized exception handling
- Structured logging
- Environment variable based config
- OpenAPI and Swagger documentation
- Clean modular project structure

## Tech Stack
- Python 3.13+
- FastAPI
- Uvicorn
- Pydantic

## Setup
Install dependencies:

```bash
py -m pip install -r requirements.txt
```

## Environment Variables
Create/update `.env` in project root:

```env
APP_NAME=AI API Service
APP_VERSION=1.0.0
DEBUG=True
```

## Run

```bash
py -m uvicorn app.main:app --reload
```

## API Documentation
- Swagger UI: `http://localhost:8000/docs`
- OpenAPI JSON: `http://localhost:8000/openapi.json`

## Endpoints

### 1) POST `/summarize`
Summarizes long input text.

Sample request:

```json
{
	"text": "FastAPI is a modern framework for building APIs in Python with automatic documentation and validation."
}
```

Sample response:

```json
{
	"summary": "FastAPI is a modern framework for building APIs in Python with automatic documentation and validation...."
}
```

### 2) POST `/translate`
Translates text into a supported target language.

Supported languages:
- english
- spanish
- french
- german
- hindi
- japanese

Sample request:

```json
{
	"text": "How are you today?",
	"target_language": "spanish"
}
```

Sample response:

```json
{
	"translated_text": "How are you today? (translated to spanish)"
}
```

### 3) POST `/generate-email`
Generates an email draft for a given purpose and recipient.

Sample request:

```json
{
	"purpose": "Project update",
	"recipient": "Hiring Manager",
	"tone": "formal"
}
```

Sample response:

```json
{
	"email": "Subject: Project update\n\nDear Hiring Manager,\n\nI hope you are doing well.\nThis email is regarding Project update.\n\nBest regards,"
}
```

## Error Handling
- Validation errors return HTTP 422
- Service errors return mapped status code with a readable `error` message
- Unhandled exceptions return HTTP 500

## Logging
Application logs include:
- request processing events
- validation and service errors
- unhandled exceptions

## Deliverables Checklist
- GitHub repository with source code
- README documentation
- API documentation (`/docs`)
- Screen recording link (to be added by candidate)
