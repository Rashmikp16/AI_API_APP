from pydantic import BaseModel, Field


class SummarizeRequest(BaseModel):
    text: str = Field(..., min_length=30, max_length=10000)


class SummarizeResponse(BaseModel):
    summary: str
