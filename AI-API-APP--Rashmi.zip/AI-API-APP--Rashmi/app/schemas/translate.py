from pydantic import BaseModel, Field, field_validator

SUPPORTED_LANGUAGES = {
    "english",
    "spanish",
    "french",
    "german",
    "hindi",
    "japanese",
}


class TranslateRequest(BaseModel):
    text: str = Field(..., min_length=3, max_length=10000)
    target_language: str = Field(..., min_length=2, max_length=30)

    @field_validator("target_language")
    @classmethod
    def validate_target_language(cls, value: str) -> str:
        normalized = value.strip().lower()
        if normalized not in SUPPORTED_LANGUAGES:
            raise ValueError(
                f"target_language must be one of: {', '.join(sorted(SUPPORTED_LANGUAGES))}"
            )
        return normalized


class TranslateResponse(BaseModel):
    translated_text: str
