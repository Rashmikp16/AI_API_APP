from pydantic import BaseModel, Field


class EmailRequest(BaseModel):
    purpose: str = Field(..., min_length=5, max_length=200)
    recipient: str = Field(..., min_length=2, max_length=120)
    tone: str = Field(default="formal", pattern="^(formal|friendly|casual)$")


class EmailResponse(BaseModel):
    email: str
