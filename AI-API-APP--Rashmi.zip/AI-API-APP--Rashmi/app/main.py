import logging

from fastapi import FastAPI, Request
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from app.core.exceptions import ServiceError
from app.routes import summarize, translate, email
from app.core.logging import setup_logging
from app.core.config import settings

setup_logging()
logger = logging.getLogger(__name__)

app = FastAPI(
	title=settings.APP_NAME,
	version=settings.APP_VERSION,
	description="REST API for summarize, translate, and email generation tasks.",
)


@app.get("/", tags=["System"], summary="Root endpoint")
async def root():
	return {
		"message": "AI API Service is running",
		"docs": "/docs",
		"openapi": "/openapi.json",
	}


@app.get("/health", tags=["System"], summary="Health check")
async def health_check():
	return {"status": "ok"}


@app.exception_handler(ServiceError)
async def service_error_handler(_: Request, exc: ServiceError):
	logger.error("Service error: %s", exc.message)
	return JSONResponse(
		status_code=exc.status_code,
		content={"error": exc.message},
	)


@app.exception_handler(RequestValidationError)
async def request_validation_error_handler(_: Request, exc: RequestValidationError):
	details = jsonable_encoder(exc.errors())
	logger.error("Validation error: %s", details)
	return JSONResponse(
		status_code=422,
		content={"error": "Invalid request payload", "details": details},
	)


@app.exception_handler(Exception)
async def unhandled_exception_handler(_: Request, exc: Exception):
	logger.exception("Unhandled server error: %s", str(exc))
	return JSONResponse(
		status_code=500,
		content={"error": "Internal server error"},
	)

app.include_router(summarize.router)
app.include_router(translate.router)
app.include_router(email.router)
