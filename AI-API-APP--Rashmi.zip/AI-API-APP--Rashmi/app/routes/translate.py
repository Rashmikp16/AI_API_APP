import logging

from fastapi import APIRouter
from app.core.exceptions import ServiceError
from app.schemas.translate import TranslateRequest, TranslateResponse
from app.services.ai_service import translate_text

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post(
    "/translate",
    response_model=TranslateResponse,
    tags=["AI Tasks"],
    summary="Translate text to a target language",
)
def translate(req: TranslateRequest):
    logger.info("Processing translate request")
    try:
        result = translate_text(req.text, req.target_language)
        logger.info("Translate request completed")
        return {"translated_text": result}
    except ServiceError:
        logger.exception("Translate request failed")
        raise
    except Exception as exc:
        logger.exception("Unexpected translate route error")
        raise ServiceError(
            "Unexpected error while processing translate request.", status_code=500
        ) from exc
