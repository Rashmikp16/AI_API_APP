import logging

from fastapi import APIRouter
from app.core.exceptions import ServiceError
from app.schemas.summarize import SummarizeRequest, SummarizeResponse
from app.services.ai_service import summarize_text

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post(
    "/summarize",
    response_model=SummarizeResponse,
    tags=["AI Tasks"],
    summary="Summarize an input text",
)
def summarize(req: SummarizeRequest):
    logger.info("Processing summarize request")
    try:
        summary = summarize_text(req.text)
        logger.info("Summarize request completed")
        return {"summary": summary}
    except ServiceError:
        logger.exception("Summarize request failed")
        raise
    except Exception as exc:
        logger.exception("Unexpected summarize route error")
        raise ServiceError(
            "Unexpected error while processing summarize request.", status_code=500
        ) from exc
