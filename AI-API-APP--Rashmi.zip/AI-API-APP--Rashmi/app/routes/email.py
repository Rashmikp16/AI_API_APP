import logging

from fastapi import APIRouter
from app.core.exceptions import ServiceError
from app.schemas.email import EmailRequest, EmailResponse
from app.services.ai_service import generate_email

router = APIRouter()
logger = logging.getLogger(__name__)


@router.post(
    "/generate-email",
    response_model=EmailResponse,
    tags=["AI Tasks"],
    summary="Generate an email draft",
)
def email(req: EmailRequest):
    logger.info("Processing generate-email request")
    try:
        result = generate_email(req.purpose, req.recipient, req.tone)
        logger.info("Generate-email request completed")
        return {"email": result}
    except ServiceError:
        logger.exception("Generate-email request failed")
        raise
    except Exception as exc:
        logger.exception("Unexpected generate-email route error")
        raise ServiceError(
            "Unexpected error while processing email generation request.",
            status_code=500,
        ) from exc
