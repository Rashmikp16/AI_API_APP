from app.core.exceptions import ServiceError


def summarize_text(text: str) -> str:
    cleaned = text.strip()
    if not cleaned:
        raise ServiceError("Input text cannot be empty.", status_code=400)
    return cleaned[:100] + "..."


def translate_text(text: str, target_language: str) -> str:
    cleaned = text.strip()
    if not cleaned:
        raise ServiceError("Input text cannot be empty.", status_code=400)
    return f"{cleaned} (translated to {target_language})"


def generate_email(purpose: str, recipient: str, tone: str) -> str:
    cleaned_purpose = purpose.strip()
    cleaned_recipient = recipient.strip()

    if not cleaned_purpose or not cleaned_recipient:
        raise ServiceError("Purpose and recipient must be provided.", status_code=400)

    tone_opening = {
        "formal": "I hope you are doing well.",
        "friendly": "Hope you are having a great day.",
        "casual": "Just wanted to quickly reach out.",
    }

    return (
        f"Subject: {cleaned_purpose}\n\n"
        f"Dear {cleaned_recipient},\n\n"
        f"{tone_opening.get(tone, tone_opening['formal'])}\n"
        f"This email is regarding {cleaned_purpose}.\n\n"
        "Best regards,"
    )
